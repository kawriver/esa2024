# refresh github PAT
usethis::create_github_token()
gitcreds::gitcreds_set()
