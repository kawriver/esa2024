# esa2024

ESA 2024 workshop: community analysis of species, traits, phylogenies, and responses to environment

ESA 2024 ---   Quantitative Community Ecology in R --- Long Beach, California --- 1-4pm PDT


### Installation

1.  Download and install **R** from: https://cran.r-project.org/  
2.  Download and install **Rstudio** from: https://posit.co/download/rstudio-desktop/  

### Related

https://ecol.shinyapps.io/esa_tutorial/
